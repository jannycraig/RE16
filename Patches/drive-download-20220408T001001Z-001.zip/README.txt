Personal Info Page v1.2
Changelog:
1.2 - added page number graphic and palette cycler to download
1.11 - fixed ANOTHER bug relating to r-text lol, i'm bad at coding
1.1 - fixed bugs relating to the conditional fourth page
1.01 - added functionality to make fourth screen not display on units with no first like
1.0 - initial release

How to install:
Go to your ModularStatScreen.event and set it to have four pages.
As MSS_page4, place this:

  ALIGN 4
  MSS_page4:
    #incbin "asm/mss_page4_runa.dmp"
	POIN PersonalDataTable
	
As RText_page4, place this:

ALIGN 4
RText_Page4:

ST_Name4:
  RMenu(0,ST_Class4,0,ST_Dislikes,0x18,0x50,0x0,NameDescGetter)
ST_Class4:
  RMenu(ST_Name4,ST_Level4,0,ST_Age,0x6,0x68,0x6E8,ClassDescGetter)
ST_Level4:
  RMenu(ST_Class4,ST_HP4,0,ST_Exp4,0x6,0x78,0x542)
ST_Exp4:
  RMenu(ST_Class4,ST_HP4,ST_Level4,ST_Age,0x26,0x78,0x543)
ST_HP4:
  RMenu(ST_Level4,0,0,ST_Age,0x6,0x88,0x544)
ST_Likes:
  RMenu(0,ST_Dislikes,ST_Name4,ST_Height,0x66,0x18,LikesDesc)
ST_Dislikes:
  RMenu(ST_Likes,ST_Age,ST_Name4,ST_Height,0x66,0x38,DislikesDesc)
ST_Age:
  RMenu(ST_Dislikes,0,ST_Class4,ST_Height,0x66,0x58,AgeDesc)
ST_Height:
  RMenu(ST_Dislikes,0,ST_Age,0,0xa6,0x58,HeightDesc)
  
As well, place the following in the PUSH/POP section of your ModularStatScreen.event:

  ORG $88690
  jumpToHack(PageNumberCheck)
  
And finally, place this as PageNumberCheck:

  ALIGN 4
  PageNumberCheck:
    #include "asm/mss_threepageconditional.lyn.event"
	POIN PersonalDataTable
	
	

The personal information uses text IDs 0xd4c (Likes:), 0xd4d (Dislikes:), 0xd4e (Height:), and 0xd4f (Age:).
As well, LikesDesc, DislikesDesc, AgeDesc, and HeightDesc are required. Example text IDs can be found below.

## LikesDesc
A list of things this[N]
character enjoys.[X]

## DislikesDesc
A list of things this[N]
character does not enjoy.[X]

## AgeDesc
This character's current age.[X]

## HeightDesc
This character's height.[X]

The "Dislikes:" uses the narrow font in the current layout, whose installer can be found here:
https://feuniverse.us/t/scraizas-crazy-asm/5624/2

In your tables folder, place the Personal Data Editor. The Personal Data Editor takes text IDs as entries.

Please credit Runa, along with Snek for the PageNumberCheck portion and Gamma for the page name graphic.