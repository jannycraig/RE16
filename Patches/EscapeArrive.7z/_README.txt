Escape/Arrive for FE8U by Sme

To install, `#include "EscapeArrive.event"`. If you are using it already, add the contents of the PostActionCalcLoop included with this package to your existing instance of it; otherwise, include it as well.
